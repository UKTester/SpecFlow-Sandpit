﻿using SpecFlowSandpit.Step_definitions;
using System;
using System.Collections;
using System.Collections.Generic;
using TechTalk.SpecFlow;
using TechTalk.SpecFlow.Assist;
using SpecFlow.Assist.Dynamic;


namespace SpecFlowSandpit
{

    [Binding]
    public class CalculatorSteps
    {
        [Given(@"I have entered (.*) into the calculator")]
        public void GivenIHaveEnteredIntoTheCalculator(int numbers)
        {
            Console.WriteLine(numbers);
        }

        [When(@"I press add")]
        public void WhenIPressAdd()
        {
            Console.WriteLine("Pressed Add button");
        }

        [Then(@"the result should be (.*) on the screen")]
        public void ThenTheResultShouldBeOnTheScreen(int result)
        {
            if (result == 120) // Grab the object which has the value 120 in the UI of your real application and replace that
                Console.WriteLine("The test PASSED");
            else
                Console.WriteLine("The test FAILED");
        }

        [When(@"I fill all the mandatory details in form")]
        public void WhenIFillAllTheMandatoryDetailsInForm(Table table)
        {
            //var details = table.CreateSet<EmployeeDetails>();

            //foreach (EmployeeDetails emp in details)
            //{
            //    Console.WriteLine("The Details of Employee :" + emp.Name);
            //    Console.WriteLine("********************************");
            //    Console.WriteLine(emp.Age);
            //    Console.WriteLine(emp.Email);
            //    Console.WriteLine(emp.Name);
            //    Console.WriteLine(emp.Phone);

            //}

            //work with Dynamic Assist
            var details = table.CreateDynamicSet();

            //Interate
            foreach (var emp in details)
            {
                Console.WriteLine("The Details of Employee :" + emp.Name);
                Console.WriteLine("********************************");
                Console.WriteLine(emp.Age);
                Console.WriteLine(emp.Email);
                Console.WriteLine(emp.Name);
                Console.WriteLine(emp.Phone);
            }
        }

        [When(@"I fill all the mandatory details in form (.*), (.*) and (.*)")]
        public void WhenIFillAllTheMandatoryDetailsInFormAnd(string name, int age, Int64 phone)
        {
            Console.WriteLine("Name :" + name);
            Console.WriteLine("Age  :" + age);
            Console.WriteLine("Phone number :" + phone);

            ScenarioContext.Current["InfoforNextStep"] = "Step1 Passed";

            Console.WriteLine(ScenarioContext.Current["InfoforNextStep"].ToString());

            List<EmployeeDetails> empDetails = new List<EmployeeDetails>()
            {
                new EmployeeDetails()
                {
                    Name = "Chris",
                    Age = 34,
                    Email = "chris@eduserv.org.uk",
                    Phone = 01225000001
                },
                new EmployeeDetails()
                {
                    Name = "Dave",
                    Age = 101,
                    Email = "Dave@eduserv.org.uk",
                    Phone = 01225000002
                },
                new EmployeeDetails()
                {
                    Name = "Ian",
                    Age = 52,
                    Email = "Ian@eduserv.org.uk",
                    Phone = 01225000003
                }
            };

            //save the value in ScenarioContext
            ScenarioContext.Current.Add("EmpDetails", empDetails);

            //Get the value out from Scenario Context
            var emplist = ScenarioContext.Current.Get<IEnumerable<EmployeeDetails>>("EmpDetails");

            foreach (EmployeeDetails emp in emplist)
            {
                Console.WriteLine("The Employee name is" + emp.Name);
                Console.WriteLine("The Employee Age is" + emp.Age);
                Console.WriteLine("The Employee Email is" + emp.Email);
                Console.WriteLine("The Employee Phone is" + emp.Phone);
                Console.WriteLine("\n");
            }

            Console.WriteLine(ScenarioContext.Current.ScenarioInfo.Title);
            Console.WriteLine(ScenarioContext.Current.CurrentScenarioBlock);
        }
    } 
}