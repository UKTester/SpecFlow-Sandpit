﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpecFlowSandpit.Step_definitions
{
    public class EmployeeDetails
    {
        public string Name { get; set; }
        public Int64 Phone { get; set; }
        public int Age { get; set; }
        public string Email { get; set; }
    }
}